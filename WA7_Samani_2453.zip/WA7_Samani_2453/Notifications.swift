//
//  Notifications.swift
//  WA7_Samani_2453
//
//  Created by Hrishika Samani on 11/3/24.
//

import Foundation
extension Notification.Name {
    static let userDidLogin = Notification.Name("userDidLogin")
}
