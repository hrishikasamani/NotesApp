//
//  UsersAPI.swift
//  WA7_Samani_2453
//
//  Created by Hrishika Samani on 11/2/24.
//

import Foundation

class UsersAPI{
    static let usersURL = "http://apis.sakibnm.work:3000/api/auth/"
}
