//
//  NotesAPI.swift
//  WA7_Samani_2453
//
//  Created by Hrishika Samani on 11/2/24.
//

import Foundation

class NotesAPI{
    static let notesURL = "http://apis.sakibnm.work:3000/api/note/"
}
